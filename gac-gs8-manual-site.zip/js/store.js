// Хранилище и расчёты: профиль, журнал, ТО, ресурс расходников
import { TO_KM, TO_MONTHS, TO_GROUPS, PARTS, WARRANTY } from './data.js';

const KEY = 'gs8.data.v1';
const DAY = 86400000;

const blank = () => ({
  v: 1,
  profile: { purchaseDate: '', vin: '', plate: '', tire: 'R20', heavy: false, name: 'GAC GS8' },
  odo: { km: 0, date: '' },
  log: [],
  backupAt: 0,
});

let state = load();
const subs = new Set();

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return Object.assign(blank(), JSON.parse(raw));
  } catch (e) {}
  return blank();
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  subs.forEach((f) => f(state));
}
export const store = {
  get: () => state,
  sub: (f) => { subs.add(f); return () => subs.delete(f); },
  setProfile(p) { state.profile = { ...state.profile, ...p }; save(); },
  setOdo(km, date = today()) {
    state.odo = { km: Math.max(0, Math.round(km)), date };
    save();
  },
  upsert(e) {
    if (!e.id) e.id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const i = state.log.findIndex((x) => x.id === e.id);
    if (i >= 0) state.log[i] = e; else state.log.push(e);
    state.log.sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.km - a.km);
    if (e.km > state.odo.km) state.odo = { km: e.km, date: e.date || today() };
    save();
  },
  remove(id) { state.log = state.log.filter((x) => x.id !== id); save(); },
  restore(entry) { state.log.push(entry); state.log.sort((a, b) => (b.date || '').localeCompare(a.date || '')); save(); },
  markBackup() { state.backupAt = Date.now(); save(); },
  replaceAll(data) { state = Object.assign(blank(), data); save(); },
};

// ---------- даты ----------
export function today() { const d = new Date(); return iso(d); }
export function iso(d) { const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000); return z.toISOString().slice(0, 10); }
export function parse(s) { if (!s) return null; const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
export function addMonths(s, n) { const d = parse(s); if (!d) return null; const r = new Date(d); r.setMonth(r.getMonth() + n); if (r.getDate() !== d.getDate()) r.setDate(0); return iso(r); }
export function daysBetween(a, b) { return Math.round((parse(b) - parse(a)) / DAY); }
export const fmtDate = (s, opt = { day: 'numeric', month: 'long', year: 'numeric' }) => (s ? parse(s).toLocaleDateString('ru-RU', opt).replace(' г.', '') : '—');
export const fmtKm = (n) => (n == null || isNaN(n) ? '—' : Math.round(n).toLocaleString('ru-RU'));
export const fmtMoney = (n) => (n ? Math.round(n).toLocaleString('ru-RU') + ' ₽' : '');
export function plural(n, a, b, c) { n = Math.abs(n) % 100; const n1 = n % 10; if (n > 10 && n < 20) return c; if (n1 > 1 && n1 < 5) return b; if (n1 === 1) return a; return c; }
export function fmtDays(d) {
  const a = Math.abs(d);
  if (a >= 60) { const m = Math.round(a / 30.44); return `${m} ${plural(m, 'месяц', 'месяца', 'месяцев')}`; }
  return `${a} ${plural(a, 'день', 'дня', 'дней')}`;
}

// ---------- ТО ----------
export function replacedAt(idx) {
  const keys = [];
  for (const g of TO_GROUPS) for (const [, cells, key] of g.ops) if (key && cells[idx] === 'З') keys.push(key);
  return keys;
}
export function toEntries() { return state.log.filter((e) => e.type === 'to' && e.to != null).sort((a, b) => a.to - b.to); }

export function currentKm() {
  const maxLog = state.log.reduce((m, e) => Math.max(m, +e.km || 0), 0);
  return Math.max(state.odo.km || 0, maxLog);
}

// Следующее ТО по правилам сервисной книжки:
// ТО-0 — 5 000 км / 3 мес. от продажи; ТО-1 — 10 000 км / 12 мес. от продажи;
// далее каждые 10 000 км / 12 мес. от пробега и даты последнего ТО.
export function nextTO() {
  const done = toEntries();
  const last = done[done.length - 1];
  const idx = last ? last.to + 1 : 0;
  const km = currentKm();
  const purchase = state.profile.purchaseDate;
  let dueKm, dueDate, startKm, startDate;
  if (idx <= 1) {
    dueKm = TO_KM[idx];
    dueDate = purchase ? addMonths(purchase, TO_MONTHS[idx]) : null;
    startKm = last ? +last.km || 0 : 0;
    startDate = purchase || last?.date;
  } else {
    startKm = +last.km || TO_KM[idx - 1];
    startDate = last.date || purchase;
    dueKm = startKm + 10000;
    dueDate = startDate ? addMonths(startDate, 12) : null;
  }
  const kmLeft = dueKm - km;
  const daysLeft = dueDate ? daysBetween(today(), dueDate) : null;
  const pKm = (km - startKm) / Math.max(1, dueKm - startKm);
  const spanDays = startDate && dueDate ? Math.max(1, daysBetween(startDate, dueDate)) : null;
  const pDays = spanDays ? daysBetween(startDate, today()) / spanDays : 0;
  const progress = Math.max(0, Math.min(1, Math.max(pKm, pDays)));
  return { idx: Math.min(idx, 10), beyond: idx > 10, dueKm, dueDate, kmLeft, daysLeft, progress, byTime: pDays > pKm,
    overdue: kmLeft < 0 || (daysLeft != null && daysLeft < 0) };
}

export function toStatus(i) {
  const done = toEntries().find((e) => e.to === i);
  if (done) return { s: 'done', e: done };
  const n = nextTO();
  if (!n.beyond && i === n.idx) return { s: n.overdue ? 'over' : 'next', n };
  if (i < n.idx) return { s: 'skip' };
  return { s: 'plan' };
}

// ---------- ресурс расходников ----------
export function partInterval(p) {
  const h = state.profile.heavy && p.heavy ? p.heavy : {};
  return { km: h.km || p.km, mo: h.mo || p.mo };
}
export function lastDone(key) {
  let best = null;
  for (const e of state.log) {
    const hit = (e.items || []).includes(key) || (e.type === 'to' && e.to != null && replacedAt(e.to).includes(key));
    if (hit && (!best || (+e.km || 0) > (+best.km || 0) || ((+e.km || 0) === (+best.km || 0) && (e.date || '') > (best.date || '')))) best = e;
  }
  return best;
}
export function partsStatus() {
  const km = currentKm();
  const purchase = state.profile.purchaseDate;
  return PARTS.map((p) => {
    const iv = partInterval(p);
    const ld = lastDone(p.key);
    const baseKm = ld ? +ld.km || 0 : 0;
    const baseDate = ld ? ld.date : purchase;
    const dueKm = baseKm + iv.km;
    const dueDate = baseDate ? addMonths(baseDate, iv.mo) : null;
    const kmLeft = dueKm - km;
    const daysLeft = dueDate ? daysBetween(today(), dueDate) : null;
    const fk = (km - baseKm) / iv.km;
    const fd = baseDate && dueDate ? daysBetween(baseDate, today()) / Math.max(1, daysBetween(baseDate, dueDate)) : 0;
    const used = Math.max(0, Math.max(fk, fd));
    let lvl = 'ok';
    if (kmLeft < 0 || (daysLeft != null && daysLeft < 0)) lvl = 'bad';
    else if (kmLeft <= 1500 || (daysLeft != null && daysLeft <= 30) || used >= .85) lvl = 'warn';
    return { ...p, iv, last: ld, kmLeft, daysLeft, dueKm, dueDate, used, lvl, byTime: fd > fk };
  }).sort((a, b) => b.used - a.used);
}

// ---------- гарантия ----------
export function warrantyStatus() {
  const pd = state.profile.purchaseDate;
  const km = currentKm();
  return WARRANTY.map((w) => {
    const months = w.years ? w.years * 12 : w.months;
    const end = pd && months ? addMonths(pd, months) : null;
    const daysLeft = end ? daysBetween(today(), end) : null;
    const kmLeft = w.km ? w.km - km : null;
    const fT = pd && end ? daysBetween(pd, today()) / Math.max(1, daysBetween(pd, end)) : 0;
    const fK = w.km ? km / w.km : 0;
    const active = (daysLeft == null || daysLeft >= 0) && (kmLeft == null || kmLeft >= 0);
    return { ...w, end, daysLeft, kmLeft, used: Math.min(1, Math.max(fT, fK)), active };
  });
}

// ---------- статистика ----------
export function stats() {
  const y = new Date().getFullYear().toString();
  let total = 0, year = 0;
  for (const e of state.log) { const c = +e.cost || 0; total += c; if ((e.date || '').startsWith(y)) year += c; }
  return { total, year, count: state.log.length };
}

// ---------- импорт / экспорт ----------
export function exportJSON() {
  return JSON.stringify({ app: 'gs8-pwa', exportedAt: new Date().toISOString(), data: state }, null, 2);
}
const TO_RE = /ТО[-\s]?(\d{1,2})/i;
const ITEM_MAP = [
  [/масл.*(двс|двиг)|масло двс|моторн/i, 'oil'], [/салон/i, 'cabin'], [/воздуш|возд\./i, 'air'], [/топлив/i, 'fuel'],
  [/тормозн.*жидк|тормоз\. жидк/i, 'brake'], [/антифриз|охлажд/i, 'coolant'], [/свеч/i, 'plugs'], [/акпп|коробк/i, 'atf'],
  [/редуктор/i, 'rear'], [/раздат/i, 'transfer'], [/ремн/i, 'belt'], [/колодк/i, 'pads_f'],
];
export function importAny(obj) {
  // 1) собственный формат
  if (obj && obj.app === 'gs8-pwa' && obj.data) return { data: obj.data, count: obj.data.log?.length || 0 };
  if (obj && obj.log && obj.profile) return { data: obj, count: obj.log.length };
  // 2) старые приложения: массив записей { date, km|mileage, items?, note?, reason?, dealer?, order? }
  const arr = Array.isArray(obj) ? obj : Object.values(obj || {}).find((v) => Array.isArray(v) && v.some((x) => x && (x.km || x.mileage))) || [];
  const cur = JSON.parse(JSON.stringify(state));
  let n = 0;
  for (const r of arr) {
    if (!r || !(r.km || r.mileage)) continue;
    const text = [r.reason, r.note, r.notes, r.recommendations, ...(r.items || [])].filter(Boolean).join(' ');
    const m = TO_RE.exec(text);
    const items = new Set();
    for (const it of r.items || []) for (const [re, k] of ITEM_MAP) if (re.test(it)) { items.add(k); break; }
    cur.log.push({
      id: 'imp' + (r.id || Math.random().toString(36).slice(2)),
      date: (r.date || '').slice(0, 10), km: +(r.km || r.mileage) || 0,
      type: m ? 'to' : (r.reason === 'Внеплановый ремонт' ? 'repair' : 'parts'), to: m ? +m[1] : null,
      items: [...items], dealer: r.dealer || '', order: r.order || '', cost: +r.cost || 0,
      note: [r.note, r.notes, r.recommendations, !items.size && r.items ? r.items.join(', ') : ''].filter(Boolean).join('\n'),
    });
    n++;
  }
  const prof = obj && obj.profile;
  if (prof) {
    if (prof.purchaseDate) cur.profile.purchaseDate = prof.purchaseDate;
    if (prof.currentMileage) cur.odo = { km: +prof.currentMileage, date: today() };
  }
  cur.log.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  return { data: cur, count: n };
}
