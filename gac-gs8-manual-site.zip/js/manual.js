// Руководство: загрузка, навигация и поиск с учётом русских окончаний
let M = null;
let loading = null;

export function manual() {
  if (M) return Promise.resolve(M);
  loading ||= fetch('data/manual.json').then((r) => r.json()).then((d) => {
    const byId = Object.fromEntries(d.sections.map((s) => [s.id, s]));
    const kids = {};
    for (const s of d.sections) {
      const p = s.id.split('.').slice(0, -1).join('.');
      if (p) (kids[p] ||= []).push(s);
    }
    for (const s of d.sections) {
      s._t = norm(s.title);
      s._x = norm(s.text);
    }
    M = { ...d, byId, children: (id) => kids[id] || [] };
    return M;
  });
  return loading;
}

const norm = (s) => (s || '').toLowerCase().replace(/ё/g, 'е');
const ENDINGS = ['иями', 'ями', 'ами', 'иях', 'ого', 'его', 'ому', 'ему', 'ыми', 'ими', 'ией', 'ией', 'ях', 'ах', 'ов', 'ев', 'ей', 'ой', 'ий', 'ый', 'ая', 'яя', 'ое', 'ее', 'ую', 'юю', 'ом', 'ем', 'ам', 'ям', 'ия', 'ие', 'а', 'я', 'о', 'е', 'ы', 'и', 'у', 'ю', 'ь', 'й'];
export function stem(w) {
  w = norm(w);
  if (!/[а-я]/.test(w) || w.length <= 3) return w;
  for (const e of ENDINGS) if (w.endsWith(e) && w.length - e.length >= 3) return w.slice(0, -e.length);
  return w;
}
function prepare(q) {
  const words = norm(q).split(/[^a-zа-я0-9-]+/i).filter((w) => w.length >= 2);
  return { words, stems: [...new Set(words.map(stem))] };
}

export function searchManual(q) {
  if (!M) return [];
  const { stems } = prepare(q);
  if (!stems.length) return [];
  const out = [];
  for (const s of M.sections) {
    if (!s.text && !s._t) continue;
    let score = 0, all = true, firstPos = -1;
    for (const st of stems) {
      const inT = s._t.includes(st);
      let cnt = 0, i = s._x.indexOf(st);
      if (i >= 0 && (firstPos < 0 || i < firstPos)) firstPos = i;
      while (i >= 0 && cnt < 30) { cnt++; i = s._x.indexOf(st, i + st.length); }
      if (!inT && !cnt) { all = false; break; }
      score += (inT ? 40 : 0) + Math.min(cnt, 20) + (s._t.startsWith(st) ? 15 : 0);
    }
    if (!all) continue;
    out.push({ s, score, stems, snip: snippet(s.text, firstPos, stems) });
  }
  return out.sort((a, b) => b.score - a.score);
}
searchManual.prepare = prepare;

const escH = (t) => t.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
function snippet(text, pos, stems) {
  if (!text) return '';
  if (pos < 0) return escH(text.slice(0, 110)) + (text.length > 110 ? '…' : '');
  const a = Math.max(0, pos - 40);
  const b = Math.min(text.length, pos + 90);
  let s = (a > 0 ? '…' : '') + text.slice(a, b) + (b < text.length ? '…' : '');
  return highlight(escH(s), stems);
}
export function highlight(html, stems) {
  if (!stems?.length) return html;
  const re = new RegExp(`(${stems.map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})[а-яёa-z0-9-]*`, 'gi');
  return html.replace(re, (m) => `<mark>${m}</mark>`);
}
