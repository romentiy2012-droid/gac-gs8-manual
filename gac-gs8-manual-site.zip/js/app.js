// GS8 — главный модуль: маршрутизация и экраны
import { TO_KM, TO_MONTHS, TO_GROUPS, TO0_EXTRA, PARTS, EXTRA_ITEMS, REF, HEAVY, ROADSIDE, SERVICE_LIFE } from './data.js';
import { store, today, fmtDate, fmtKm, fmtMoney, fmtDays, plural, nextTO, toStatus, partsStatus, warrantyStatus, stats, replacedAt, currentKm, exportJSON, importAny, addMonths } from './store.js';
import { $, $$, esc, icon, chev, toast, sheet, closeAllSheets, hasSheet, zoomImage, confirmSheet, ring } from './ui.js';
import { manual, searchManual, highlight } from './manual.js';

const view = $('#view');
const topbar = $('#topbar');
const scrollMem = new Map();
let curPath = '';
let io;

const PART_NAME = Object.fromEntries([...PARTS.map((p) => [p.key, p.short]), ...EXTRA_ITEMS]);
const TYPE = { to: 'Плановое ТО', repair: 'Ремонт', parts: 'Замена / обслуживание', other: 'Другое' };
const COLORS = { red: 'Красный', yellow: 'Жёлтый', green: 'Зелёный', blue: 'Синий', white: 'Белый', gray: 'Серый' };
const CHAP_COLORS = ['#ff3b30', '#5856d6', '#ff9500', '#0a84ff', '#34c759', '#af52de', '#8e8e93', '#ff2d55'];

// ---------- роутер ----------
const routes = [
  [/^\/home$/, home],
  [/^\/service(?:\/(to|log|parts))?$/, service],
  [/^\/manual$/, manualHome],
  [/^\/manual\/c\/(\d+)$/, manualChapter],
  [/^\/manual\/s\/([\d.]+)$/, manualSection],
  [/^\/indicators$/, indicators],
  [/^\/ref$/, refHome],
  [/^\/ref\/(warranty|settings|heavy|about)$/, refPage],
  [/^\/ref\/([a-z]+)$/, refDetail],
];
async function render() {
  const raw = location.hash.slice(1) || '/home';
  const [path, qs] = raw.split('?');
  const q = new URLSearchParams(qs || '');
  if (curPath) scrollMem.set(curPath, window.scrollY);
  closeAllSheets();
  const tab = path.split('/')[1] || 'home';
  $$('#tabbar a').forEach((a) => a.classList.toggle('active', a.dataset.tab === tab));
  for (const [re, fn] of routes) {
    const m = path.match(re);
    if (m) {
      curPath = raw;
      view.classList.remove('enter'); void view.offsetWidth; view.classList.add('enter');
      await fn(...m.slice(1), q);
      setupTopbar();
      const y = scrollMem.get(raw);
      window.scrollTo(0, y || 0);
      return;
    }
  }
  location.replace('#/home');
}
function go(h) { location.hash = h; }
window.addEventListener('hashchange', render);
// повторное нажатие на вкладку — прокрутка вверх / в корень раздела
$('#tabbar').addEventListener('click', (e) => {
  const a = e.target.closest('a'); if (!a) return;
  const root = a.getAttribute('href');
  if (location.hash === root) { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  else if (location.hash.startsWith(root)) { e.preventDefault(); scrollMem.delete(root.slice(1)); go(root); }
});

function setupTopbar() {
  io && io.disconnect();
  const h = view.querySelector('[data-title]');
  $('#topbarTitle').textContent = h ? h.dataset.title : '';
  topbar.classList.remove('show');
  if (!h) return;
  io = new IntersectionObserver(([en]) => topbar.classList.toggle('show', !en.isIntersecting && en.boundingClientRect.top < 60), { rootMargin: '-50px 0px 0px 0px' });
  io.observe(h);
}
const LT = (title, sub = '', right = '', back = '') => `${back ? `<button class="back" data-back="${esc(back)}">${icon('back')}<span>Назад</span></button>` : ''}<div class="lt"><div><h1 data-title="${esc(title)}">${esc(title)}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div>${right}</div>`;
view.addEventListener('click', (e) => {
  const b = e.target.closest('[data-back]');
  if (b) { if (history.length > 1 && b.dataset.back === 'history') history.back(); else go(b.dataset.back); }
});

// ---------- ГЛАВНАЯ ----------
function home() {
  const st = store.get();
  const p = st.profile;
  const km = currentKm();
  const n = nextTO();
  const parts = partsStatus();
  const needSetup = !p.purchaseDate;
  const col = n.overdue ? 'var(--bad)' : n.progress > .85 ? 'var(--warn)' : 'var(--ok)';
  const center = n.overdue ? '<b style="color:var(--bad)">!</b><span>просрочено</span>' : `<b>${Math.round(n.progress * 100)}%</b><span>интервала</span>`;
  const leftTxt = [];
  if (n.kmLeft != null) leftTxt.push(n.kmLeft >= 0 ? `через ${fmtKm(n.kmLeft)} км` : `перепробег ${fmtKm(-n.kmLeft)} км`);
  if (n.daysLeft != null) leftTxt.push(n.daysLeft >= 0 ? `или ${fmtDays(n.daysLeft)}` : `просрочено на ${fmtDays(n.daysLeft)}`);
  const w = warrantyStatus()[0];
  const daysSinceBackup = st.backupAt ? Math.floor((Date.now() - st.backupAt) / 864e5) : null;
  const needBackup = st.log.length > 0 && (daysSinceBackup == null || daysSinceBackup > 30);
  const odoAge = st.odo.date ? Math.floor((Date.now() - new Date(st.odo.date)) / 864e5) : null;

  const legacy = !st.log.length && legacyData();
  view.innerHTML = `
  <div class="hero"><img src="img/hero.webp" alt="" fetchpriority="high">
    <div class="hero-top"><span class="brand">GAC MOTOR</span><button class="iconbtn" id="btnSettings" aria-label="Настройки">${icon('gear')}</button></div>
  </div>
  <div class="hero-info">
    <div class="model" data-title="${esc(p.name || 'GAC GS8')}">${esc(p.name || 'GAC GS8')}</div>
    ${p.plate ? `<span class="plate">${esc(p.plate)}</span>` : ''}
    <div class="odo"><div><div class="val num">${fmtKm(km)}<small>км</small></div>
      <div class="lbl">${st.odo.date ? `пробег на ${fmtDate(st.odo.date, { day: 'numeric', month: 'long' })}` : 'укажите текущий пробег'}</div></div>
      <button class="pill" id="btnOdo">${icon('gauge')}Пробег</button></div>
  </div>

  ${legacy ? `<button class="banner" id="bLegacy">${icon('cloud')}<div><b>Найдены записи старой версии</b><span>${legacy.count} шт. Нажмите, чтобы перенести в журнал.</span></div></button>` : ''}
  ${needSetup ? `<button class="banner" id="bSetup">${icon('car')}<div><b>Укажите дату покупки</b><span>Нужна для расчёта ТО по времени и гарантии.</span></div></button>` : ''}
  ${!needSetup && odoAge != null && odoAge > 14 ? `<button class="banner" id="bOdo">${icon('gauge')}<div><b>Обновите пробег</b><span>Последний раз — ${fmtDays(odoAge)} назад. От пробега зависит прогноз ТО.</span></div></button>` : ''}

  <div class="h2">Следующее ТО</div>
  <div class="card">
    ${n.beyond ? `<div class="muted">Регламент сервисной книжки расписан до ТО-10 (100 000 км). Далее — по рекомендации дилера.</div>` : `
    <div class="next">${ring(n.progress, col, center)}
      <div><div class="ttl">ТО-${n.idx}${n.idx === 0 ? ' · бесплатно' : ''}</div>
        <div class="big num">${fmtKm(n.dueKm)} км${n.dueDate ? ` · ${fmtDate(n.dueDate, { day: 'numeric', month: 'short', year: 'numeric' })}` : ''}</div>
        <div class="det">${leftTxt.join(' ') || '—'}</div>
      </div></div>
    <div class="next act" style="display:flex;gap:8px;margin-top:14px"><button class="pill ghost" id="btnToInfo">Что входит</button><button class="pill soft" id="btnToDone">${icon('check')}Пройдено</button></div>`}
  </div>

  <div class="quick">
    <a href="tel:${ROADSIDE.phone}"><span class="qi" style="background:#ff3b30">${icon('phone')}</span>Помощь на дороге</a>
    <button data-go="#/indicators"><span class="qi" style="background:#ff9500">${icon('warn')}</span>Индикаторы</button>
    <button data-go="#/ref/fluids"><span class="qi" style="background:#0a84ff">${icon('drop')}</span>Жидкости</button>
    <button data-go="#/ref/tires"><span class="qi" style="background:#34c759">${icon('tire')}</span>Шины</button>
  </div>

  <div class="h2">Ресурс<a href="#/service/parts">Все</a></div>
  <div class="list">${parts.slice(0, 4).map(partRow).join('')}</div>
  ${p.heavy ? `<div class="note">Учтены тяжёлые условия эксплуатации.</div>` : ''}

  <div class="h2">Гарантия<a href="#/ref/warranty">Подробнее</a></div>
  <div class="card">${needSetup ? '<div class="muted">Укажите дату покупки в настройках.</div>' : `
    <div class="part"><div class="top"><span class="nm">${w.active ? 'Основная гарантия действует' : 'Основная гарантия закончилась'}</span>
    <span class="tag ${w.active ? 'ok' : 'bad'}">${w.active ? 'активна' : 'истекла'}</span></div>
    <div class="meter"><i class="${w.used > .9 ? 'warn' : ''}" style="width:${Math.round(w.used * 100)}%"></i></div>
    <div class="small muted" style="margin-top:6px">до ${fmtDate(w.end)} или ${fmtKm(w.km)} км · осталось ${w.daysLeft >= 0 ? fmtDays(w.daysLeft) : '0'} / ${fmtKm(Math.max(0, w.kmLeft))} км</div></div>`}
  </div>

  <div class="h2">Последние записи<a href="#/service/log">Журнал</a></div>
  ${st.log.length ? `<div class="list">${st.log.slice(0, 3).map(logRow).join('')}</div>` : `<div class="card empty" style="padding:22px">${icon('wrench')}Журнал пуст.<br><button class="pill" style="margin-top:12px" id="btnAdd">${icon('plus')}Добавить запись</button></div>`}
  ${needBackup ? `<button class="banner" id="bBackup">${icon('cloud')}<div><b>Сделайте резервную копию</b><span>${daysSinceBackup == null ? 'Копии ещё не было.' : `Последняя — ${fmtDays(daysSinceBackup)} назад.`} Данные хранятся только на этом iPhone.</span></div></button>` : ''}
  `;
  $('#btnSettings').onclick = openSettings;
  $('#btnOdo').onclick = openOdo;
  $('#bSetup') && ($('#bSetup').onclick = openSettings);
  $('#bLegacy') && ($('#bLegacy').onclick = () => { const cur = store.get(); const d = legacy.data; d.profile = { ...cur.profile, ...(d.profile.purchaseDate ? { purchaseDate: d.profile.purchaseDate } : {}) }; store.replaceAll(d); render(); toast(`Перенесено записей: ${legacy.count}`); });
  $('#bOdo') && ($('#bOdo').onclick = openOdo);
  $('#bBackup') && ($('#bBackup').onclick = doExport);
  $('#btnAdd') && ($('#btnAdd').onclick = () => openEntry());
  $('#btnToInfo') && ($('#btnToInfo').onclick = () => openTO(n.idx));
  $('#btnToDone') && ($('#btnToDone').onclick = () => openEntry({ type: 'to', to: n.idx }));
  bindCommon();
}
function legacyData() {
  for (const k of ['gac-service-data-v2', 'gac_logs']) {
    try {
      const raw = localStorage.getItem(k); if (!raw) continue;
      const r = importAny(JSON.parse(raw));
      if (r.count) return r;
    } catch (e) {}
  }
  return null;
}
function bindCommon() {
  $$('[data-go]', view).forEach((b) => (b.onclick = () => go(b.dataset.go)));
  $$('[data-entry]', view).forEach((b) => (b.onclick = () => openEntry(store.get().log.find((e) => e.id === b.dataset.entry))));
  $$('[data-part]', view).forEach((b) => (b.onclick = () => openPart(b.dataset.part)));
}
// Остаток по пробегу и по времени; первым идёт то, что наступит раньше
function partLeft(p) {
  const km = p.kmLeft < 0 ? `перепробег ${fmtKm(-p.kmLeft)} км` : `${fmtKm(p.kmLeft)} км`;
  const t = p.daysLeft == null ? null : p.daysLeft < 0 ? `просрочено ${fmtDays(p.daysLeft)}` : `≈ ${fmtDays(p.daysLeft)}`;
  let timeFirst = p.byTime;
  if (p.kmLeft < 0 && !(p.daysLeft < 0)) timeFirst = false;
  if (p.daysLeft != null && p.daysLeft < 0 && p.kmLeft >= 0) timeFirst = true;
  if (!t) timeFirst = false;
  return { km, t, timeFirst, first: timeFirst ? t : km, second: timeFirst ? km : t };
}
function partRow(p) {
  const pct = Math.min(100, Math.round(p.used * 100));
  const L = partLeft(p);
  return `<button class="row part" data-part="${p.key}"><div class="top"><span class="nm">${esc(p.short)}</span><span class="rm num"><b class="${p.lvl === 'ok' ? '' : p.lvl}">${L.first}</b>${L.second ? `<span class="sec"> · ${L.second}</span>` : ''}</span></div>
  <div class="meter"><i class="${p.lvl === 'ok' ? '' : p.lvl}" style="width:${pct}%"></i></div></button>`;
}
function logRow(e) {
  const title = e.type === 'to' && e.to != null ? `ТО-${e.to}` : TYPE[e.type] || 'Запись';
  const items = (e.items || []).map((k) => `<span class="tag">${esc(PART_NAME[k] || k)}</span>`).join('');
  return `<button class="row log-e" data-entry="${e.id}"><div class="grow"><div class="t">${esc(title)}</div>
    <div class="s num">${fmtDate(e.date, { day: 'numeric', month: 'short', year: 'numeric' })} · ${fmtKm(e.km)} км${e.dealer ? ' · ' + esc(e.dealer) : ''}</div>
    ${items ? `<div class="items">${items}</div>` : ''}</div>${e.cost ? `<span class="cost num">${fmtMoney(e.cost)}</span>` : ''}${chev}</button>`;
}

// ---------- СЕРВИС ----------
function service(tab = 'to') {
  const s = stats();
  view.innerHTML = `${LT('Сервис', '', `<button class="pill" id="btnNew" style="margin-bottom:4px">${icon('plus')}Запись</button>`)}
  <div class="seg" id="seg"><button data-t="to">График ТО</button><button data-t="log">Журнал</button><button data-t="parts">Ресурс</button></div>
  <div id="svc"></div>`;
  $$('#seg button').forEach((b) => { b.classList.toggle('on', b.dataset.t === tab); b.onclick = () => location.replace('#/service/' + b.dataset.t); });
  $('#btnNew').onclick = () => openEntry();
  const box = $('#svc');
  if (tab === 'to') {
    const n = nextTO();
    box.innerHTML = `<div class="list">${TO_KM.map((km, i) => {
      const st = toStatus(i);
      const cls = st.s === 'done' ? 'done' : st.s === 'next' ? 'is-next' : st.s === 'over' ? 'over' : '';
      const repl = replacedAt(i).filter((k) => !['oil', 'cabin', 'air', 'fuel'].includes(k)).map((k) => PARTS.find((p) => p.key === k).short);
      let sub = `${fmtKm(km)} км · ${TO_MONTHS[i]} мес.`;
      let tag = '';
      if (st.s === 'done') tag = `<span class="tag ok">${fmtDate(st.e.date, { day: 'numeric', month: 'short', year: '2-digit' })}</span>`;
      else if (st.s === 'next') tag = `<span class="tag acc">следующее</span>`;
      else if (st.s === 'over') tag = `<span class="tag bad">просрочено</span>`;
      else if (st.s === 'skip') tag = `<span class="tag">нет записи</span>`;
      return `<button class="row to-row ${cls}" data-to="${i}"><span class="badge">${i}</span><div class="grow"><div class="t">ТО-${i}${i === 0 ? ' <span class="tag ok">бесплатно</span>' : ''}</div>
      <div class="s">${sub}${repl.length ? ` · <span style="color:var(--accent)">+ ${esc(repl.join(', '))}</span>` : ''}</div></div>${tag}${chev}</button>`;
    }).join('')}</div>
    <div class="note">ТО-0 — 5 000 км или 3 месяца, ТО-1 — 10 000 км или 12 месяцев от продажи. Далее каждые 10 000 км или 12 месяцев от последнего ТО — что наступит раньше. Допуск ±500 км.</div>
    <button class="banner" data-go="#/ref/heavy">${icon('warn')}<div><b>Тяжёлые условия эксплуатации</b><span>Масло и фильтр салона — каждые 5 000 км. Нажмите, чтобы узнать подробнее.</span></div></button>`;
    $$('[data-to]', box).forEach((b) => (b.onclick = () => openTO(+b.dataset.to)));
  } else if (tab === 'log') {
    const log = store.get().log;
    box.innerHTML = `<div class="stats"><div class="stat"><b class="num">${s.count}</b><span>записей</span></div>
      <div class="stat"><b class="num">${fmtMoney(s.year) || '0 ₽'}</b><span>в этом году</span></div>
      <div class="stat"><b class="num">${fmtMoney(s.total) || '0 ₽'}</b><span>всего</span></div></div>
      ${log.length ? groupByYear(log) : `<div class="card empty">${icon('wrench')}Здесь будет история обслуживания:<br>ТО, ремонты, замены расходников.</div>`}`;
  } else {
    const ps = partsStatus();
    box.innerHTML = `<div class="list">${ps.map(partRow).join('')}</div>
    <div class="note">Ресурс считается от последней замены в журнале (или от даты покупки) по интервалам сервисной книжки${store.get().profile.heavy ? ' с учётом тяжёлых условий' : ''}. Нажмите на строку, чтобы отметить замену.</div>`;
  }
  bindCommon();
}
function groupByYear(log) {
  const by = {};
  for (const e of log) (by[(e.date || '—').slice(0, 4)] ||= []).push(e);
  return Object.keys(by).sort().reverse().map((y) => `<div class="cap">${y}</div><div class="list">${by[y].map(logRow).join('')}</div>`).join('');
}

function opsFor(i) {
  return TO_GROUPS.map((g) => {
    const ops = g.ops.filter(([, c]) => c[i] !== '.');
    if (!ops.length) return '';
    ops.sort((a, b) => (a[1][i] === 'З' ? -1 : 0) - (b[1][i] === 'З' ? -1 : 0));
    return `<h4>${esc(g.title)}</h4>${ops.map(([t, c]) => `<div class="op"><span class="k ${c[i] === 'З' ? 'z' : ''}">${c[i]}</span><span>${esc(t)}</span></div>`).join('')}`;
  }).join('') + (i === 0 ? `<h4>Талон ТО-0</h4>${TO0_EXTRA.map((t) => `<div class="op"><span class="k">П</span><span>${esc(t)}</span></div>`).join('')}` : '');
}
function openTO(i) {
  const st = toStatus(i);
  const z = replacedAt(i).length;
  const body = `<div class="card" style="display:flex;justify-content:space-between;align-items:center">
    <div><div style="font-size:28px;font-weight:800;letter-spacing:-.5px">ТО-${i}</div><div class="muted num">${fmtKm(TO_KM[i])} км · ${TO_MONTHS[i]} мес.</div></div>
    <div style="text-align:right">${st.s === 'done' ? `<span class="tag ok">пройдено</span><div class="small muted num" style="margin-top:4px">${fmtDate(st.e.date)} · ${fmtKm(st.e.km)} км</div>` : i === 0 ? '<span class="tag ok">бесплатно</span>' : ''}</div></div>
    <div class="card ops" style="padding-top:4px;margin-top:12px"><div class="small muted" style="margin-top:12px"><b style="color:var(--accent)">З</b> — замена (${z}), <b>П</b> — проверка</div>${opsFor(i)}</div>
    ${st.s === 'done' ? `<button class="btn sec" id="toOpen">Открыть запись</button>` : `<button class="btn" id="toMark">${icon('check')}Отметить пройденным</button>`}`;
  const s = sheet({ title: `ТО-${i}`, body, full: true });
  const m = s.el.querySelector('#toMark'); if (m) m.onclick = () => { s.close(); openEntry({ type: 'to', to: i }); };
  const o = s.el.querySelector('#toOpen'); if (o) o.onclick = () => { s.close(); openEntry(st.e); };
}

function openPart(key) {
  const p = partsStatus().find((x) => x.key === key);
  const iv = p.iv;
  const body = `<div class="card"><div style="font-size:22px;font-weight:700">${esc(p.name)}</div>
    ${p.note ? `<div class="muted small" style="margin-top:4px">${esc(p.note)}</div>` : ''}
    <div class="meter" style="margin-top:14px;height:8px"><i class="${p.lvl === 'ok' ? '' : p.lvl}" style="width:${Math.min(100, Math.round(p.used * 100))}%"></i></div></div>
    <div class="list" style="margin-top:12px">
      <div class="row"><span class="grow">Интервал</span><span class="v num">${fmtKm(iv.km)} км / ${iv.mo} мес.</span></div>
      <div class="row"><span class="grow">Последняя замена</span><span class="v num">${p.last ? `${fmtDate(p.last.date, { day: 'numeric', month: 'short', year: 'numeric' })}, ${fmtKm(p.last.km)} км` : 'нет записи'}</span></div>
      <div class="row"><span class="grow">Следующая</span><span class="v strong num">${fmtKm(p.dueKm)} км${p.dueDate ? ` или ${fmtDate(p.dueDate, { day: 'numeric', month: 'short', year: 'numeric' })}` : ''}</span></div>
      ${(() => { const L = partLeft(p); const c = p.lvl === 'ok' ? 'inherit' : `var(--${p.lvl})`;
        return `<div class="row"><span class="grow">Осталось по пробегу</span><span class="v num ${L.timeFirst ? '' : 'strong'}" style="${L.timeFirst ? '' : `color:${c}`}">${L.km}</span></div>
      <div class="row"><span class="grow">Осталось по времени</span><span class="v num ${L.timeFirst ? 'strong' : ''}" style="${L.timeFirst ? `color:${c}` : ''}">${L.t || 'укажите дату покупки'}</span></div>`; })()}
    </div>
    ${p.heavy && store.get().profile.heavy ? `<div class="note">Интервал сокращён: включены тяжёлые условия.</div>` : ''}
    <button class="btn" id="pDone">${icon('check')}Отметить замену</button>`;
  const s = sheet({ title: p.short, body });
  s.el.querySelector('#pDone').onclick = () => { s.close(); openEntry({ type: 'parts', items: [key] }); };
}

// ---------- редактор записи ----------
function openEntry(src) {
  const isEdit = !!(src && src.id);
  const e = { date: today(), km: currentKm() || '', type: 'parts', to: null, items: [], dealer: '', order: '', cost: '', note: '', ...(src ? JSON.parse(JSON.stringify(src)) : {}) };
  if (!isEdit && e.type === 'to' && e.to != null && !e.items.length) e.items = [];
  const f = document.createElement('div');
  f.className = 'form';
  const toOpts = TO_KM.map((k, i) => `<option value="${i}" ${e.to === i ? 'selected' : ''}>ТО-${i} (${fmtKm(k)} км)</option>`).join('');
  f.innerHTML = `
  <div class="seg" id="eType">${Object.entries({ to: 'ТО', parts: 'Замена', repair: 'Ремонт', other: 'Другое' }).map(([k, v]) => `<button data-t="${k}" class="${e.type === k ? 'on' : ''}">${v}</button>`).join('')}</div>
  <div class="list">
    <div class="fld" id="toFld" ${e.type === 'to' ? '' : 'hidden'}><label>Номер ТО</label><select id="eTo">${toOpts}</select></div>
    <div class="fld"><label>Дата</label><input type="date" id="eDate" value="${esc(e.date)}" max="${today()}"></div>
    <div class="fld"><label>Пробег, км</label><input id="eKm" inputmode="numeric" pattern="[0-9]*" value="${esc(e.km)}" placeholder="например, 15 000"></div>
  </div>
  <div class="cap" id="capItems">${e.type === 'to' ? 'Дополнительно заменено' : 'Что заменено'}</div>
  <div class="list"><div class="pick" id="ePick">${[...PARTS.map((p) => [p.key, p.short]), ...EXTRA_ITEMS].map(([k, v]) => `<button data-k="${k}" class="${e.items.includes(k) ? 'on' : ''}">${esc(v)}</button>`).join('')}</div></div>
  <div class="note" id="toNote" ${e.type === 'to' ? '' : 'hidden'}>Замены по регламенту выбранного ТО учитываются автоматически.</div>
  <div class="cap">Детали</div>
  <div class="list">
    <div class="fld"><label>Сервис / дилер</label><input id="eDealer" value="${esc(e.dealer)}" placeholder="название"></div>
    <div class="fld"><label>№ заказ-наряда</label><input id="eOrder" value="${esc(e.order)}"></div>
    <div class="fld"><label>Стоимость, ₽</label><input id="eCost" inputmode="numeric" pattern="[0-9]*" value="${esc(e.cost || '')}"></div>
    <div class="fld"><label>Заметка</label><textarea id="eNote" rows="3" placeholder="масло, бренд колодок, рекомендации мастера…">${esc(e.note)}</textarea></div>
  </div>
  ${isEdit ? '<button class="btn danger" id="eDel">Удалить запись</button>' : ''}`;
  const s = sheet({ title: isEdit ? 'Запись' : 'Новая запись', left: 'Отмена', right: 'Готово', full: true, body: f, onRight: saveIt });
  const typeBtns = $$('#eType button', f);
  typeBtns.forEach((b) => (b.onclick = () => {
    e.type = b.dataset.t; typeBtns.forEach((x) => x.classList.toggle('on', x === b));
    $('#toFld', f).hidden = e.type !== 'to'; $('#toNote', f).hidden = e.type !== 'to';
    $('#capItems', f).textContent = e.type === 'to' ? 'Дополнительно заменено' : 'Что заменено';
  }));
  $$('#ePick button', f).forEach((b) => (b.onclick = () => b.classList.toggle('on')));
  const kmIn = $('#eKm', f);
  const fmtInput = (inp) => inp.addEventListener('input', () => { const v = inp.value.replace(/\D/g, ''); inp.value = v ? (+v).toLocaleString('ru-RU') : ''; });
  fmtInput(kmIn); fmtInput($('#eCost', f));
  if (kmIn.value) kmIn.value = (+String(kmIn.value).replace(/\D/g, '')).toLocaleString('ru-RU');
  if ($('#eCost', f).value) $('#eCost', f).value = (+$('#eCost', f).value).toLocaleString('ru-RU');
  if (isEdit) $('#eDel', f).onclick = () => confirmSheet('Удалить запись без возможности восстановления?', 'Удалить', () => {
    const copy = store.get().log.find((x) => x.id === e.id);
    store.remove(e.id); s.close(); render();
    toast('Запись удалена', { label: 'Вернуть', fn: () => { store.restore(copy); render(); } });
  });
  function saveIt() {
    const km = +kmIn.value.replace(/\D/g, '');
    if (!km) { kmIn.focus(); toast('Укажите пробег'); return; }
    const out = {
      id: e.id, date: $('#eDate', f).value || today(), km, type: e.type,
      to: e.type === 'to' ? +$('#eTo', f).value : null,
      items: $$('#ePick button.on', f).map((b) => b.dataset.k),
      dealer: $('#eDealer', f).value.trim(), order: $('#eOrder', f).value.trim(),
      cost: +$('#eCost', f).value.replace(/\D/g, '') || 0, note: $('#eNote', f).value.trim(),
    };
    store.upsert(out); s.close(); render();
    toast(isEdit ? 'Сохранено' : 'Запись добавлена');
  }
}

// ---------- пробег ----------
function openOdo() {
  const cur = currentKm();
  const f = document.createElement('div');
  f.innerHTML = `<div class="card form" style="padding:18px 8px"><input id="oKm" class="big-input num" inputmode="numeric" pattern="[0-9]*" value="${cur ? cur.toLocaleString('ru-RU') : ''}" placeholder="0" aria-label="Пробег, км">
  <div class="muted small" style="text-align:center">километров на одометре</div></div>
  <div class="note">Прогноз ТО и ресурса расходников считается от этого значения.</div>`;
  const s = sheet({ title: 'Текущий пробег', left: 'Отмена', right: 'Готово', body: f, onRight: () => {
    const v = +$('#oKm', f).value.replace(/\D/g, '');
    if (!v && v !== 0) return;
    if (v < cur && !confirm('Пробег меньше, чем в журнале. Сохранить?')) return;
    store.setOdo(v); s.close(); render(); toast('Пробег обновлён');
  } });
  const inp = $('#oKm', f);
  inp.addEventListener('input', () => { const v = inp.value.replace(/\D/g, ''); inp.value = v ? (+v).toLocaleString('ru-RU') : ''; });
  setTimeout(() => { inp.focus(); inp.select(); }, 350);
}

// ---------- настройки ----------
function openSettings() {
  const p = store.get().profile;
  const theme = localStorage.getItem('gs8.theme') || 'auto';
  const f = document.createElement('div');
  f.className = 'form';
  f.innerHTML = `
  <div class="cap">Автомобиль</div>
  <div class="list">
    <div class="fld"><label>Название</label><input id="sName" value="${esc(p.name)}"></div>
    <div class="fld"><label>Госномер</label><input id="sPlate" value="${esc(p.plate)}" placeholder="А 000 АА 00" autocapitalize="characters"></div>
    <div class="fld"><label>VIN</label><input id="sVin" value="${esc(p.vin)}" maxlength="17" autocapitalize="characters" spellcheck="false"></div>
    <div class="fld"><label>Дата покупки (начало гарантии)</label><input type="date" id="sDate" value="${esc(p.purchaseDate)}" max="${today()}"></div>
    <div class="fld inline"><label>Шины</label><select id="sTire" style="width:auto;text-align:right;color:var(--text2)"><option ${p.tire === 'R19' ? 'selected' : ''}>R19</option><option ${p.tire !== 'R19' ? 'selected' : ''}>R20</option></select></div>
    <div class="fld inline"><label>Тяжёлые условия</label><span class="switch"><input type="checkbox" id="sHeavy" ${p.heavy ? 'checked' : ''}><span></span></span></div>
  </div>
  <div class="note">${esc(HEAVY.text)}</div>
  <div class="cap">Оформление</div>
  <div class="list"><div class="fld"><div class="seg" id="sTheme" style="margin:4px 0">${[['auto', 'Авто'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([k, v]) => `<button data-v="${k}" class="${theme === k ? 'on' : ''}">${v}</button>`).join('')}</div></div></div>
  <div class="cap">Данные</div>
  <div class="list">
    <button class="row hasicon" id="sExport"><span class="ibox" style="background:#0a84ff">${icon('share')}</span><span class="grow">Сохранить резервную копию</span>${chev}</button>
    <button class="row hasicon" id="sImport"><span class="ibox" style="background:#34c759">${icon('cloud')}</span><span class="grow">Восстановить из файла</span>${chev}</button>
  </div>
  <div class="note">Данные хранятся только на этом устройстве. Сохраняйте копию в «Файлы» или iCloud Drive. Импорт понимает и файлы старых версий журнала.</div>
  <input type="file" id="sFile" accept="application/json,.json" hidden>
  <button class="btn danger" id="sReset">Стереть все данные</button>
  <div class="note" style="text-align:center;margin-top:18px">GS8 · версия ${window.GS8_VERSION || ''}<br>Данные: руководство по эксплуатации и сервисная книжка GAC GS8</div>`;
  const s = sheet({ title: 'Настройки', left: 'Отмена', right: 'Готово', full: true, body: f, onRight: () => {
    store.setProfile({
      name: $('#sName', f).value.trim() || 'GAC GS8', plate: $('#sPlate', f).value.trim().toUpperCase(),
      vin: $('#sVin', f).value.trim().toUpperCase(), purchaseDate: $('#sDate', f).value,
      tire: $('#sTire', f).value, heavy: $('#sHeavy', f).checked,
    });
    s.close(); render(); toast('Сохранено');
  } });
  $$('#sTheme button', f).forEach((b) => (b.onclick = () => { $$('#sTheme button', f).forEach((x) => x.classList.toggle('on', x === b)); setTheme(b.dataset.v); }));
  $('#sExport', f).onclick = doExport;
  $('#sImport', f).onclick = () => $('#sFile', f).click();
  $('#sFile', f).onchange = async (ev) => {
    const file = ev.target.files[0]; if (!file) return;
    try {
      const obj = JSON.parse(await file.text());
      const { data, count } = importAny(obj);
      confirmSheet(`Найдено записей: ${count}. Текущие данные будут заменены данными из файла.`, 'Восстановить', () => { store.replaceAll(data); s.close(); render(); toast('Данные восстановлены'); });
    } catch (err) { toast('Не удалось прочитать файл'); }
    ev.target.value = '';
  };
  $('#sReset', f).onclick = () => confirmSheet('Удалить журнал, пробег и настройки? Сначала сохраните резервную копию.', 'Стереть всё', () => { localStorage.removeItem('gs8.data.v1'); location.reload(); });
}
function setTheme(v) {
  try { if (v === 'auto') localStorage.removeItem('gs8.theme'); else localStorage.setItem('gs8.theme', v); } catch (e) {}
  if (v === 'auto') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = v;
}
async function doExport() {
  const json = exportJSON();
  const name = `GS8-журнал-${today()}.json`;
  const file = new File([json], name, { type: 'application/json' });
  try {
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: 'Резервная копия GS8' });
      store.markBackup(); toast('Копия сохранена'); render(); return;
    }
  } catch (e) { if (e.name === 'AbortError') return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(file); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  store.markBackup(); toast('Файл копии сохранён');
}

// ---------- РУКОВОДСТВО ----------
const mprefs = () => { try { return JSON.parse(localStorage.getItem('gs8.manual') || '{}'); } catch (e) { return {}; } };
const setMprefs = (p) => { try { localStorage.setItem('gs8.manual', JSON.stringify(p)); } catch (e) {} };

async function manualHome(q) {
  const M = await manual();
  const pr = mprefs();
  const query = q?.get?.('q') || '';
  view.innerHTML = `${LT('Руководство', 'По эксплуатации GAC GS8')}
  <div class="search" id="mSearch">${icon('search')}<input id="mq" type="search" placeholder="Поиск: масло, ремень, AutoHold…" value="${esc(query)}" enterkeyhint="search" autocomplete="off"><button class="x" aria-label="Очистить">✕</button></div>
  <div id="mBody"></div>`;
  const inp = $('#mq'), box = $('#mBody'), wrap = $('#mSearch');
  const renderBody = () => {
    const v = inp.value.trim();
    wrap.classList.toggle('has', !!v);
    if (v.length >= 2) {
      const res = searchManual(v);
      box.innerHTML = res.length ? `<div class="cap">Найдено: ${res.length}</div><div class="list res">${res.slice(0, 60).map((r) => `<a class="row" href="#/manual/s/${r.s.id}?q=${encodeURIComponent(v)}"><span class="sec-num">${r.s.id}</span><div class="grow"><div class="t">${highlight(esc(r.s.title), r.stems)}</div><div class="s">${r.snip}</div></div>${chev}</a>`).join('')}</div>`
        : `<div class="card empty">${icon('search')}Ничего не найдено по запросу «${esc(v)}».</div>`;
      return;
    }
    const bm = (pr.bm || []).map((id) => M.byId[id]).filter(Boolean);
    const rec = (pr.recent || []).map((id) => M.byId[id]).filter(Boolean).slice(0, 4);
    box.innerHTML = `
    ${bm.length ? `<div class="cap">Закладки</div><div class="list">${bm.map((s) => secRow(s)).join('')}</div>` : ''}
    ${rec.length ? `<div class="cap">Недавние</div><div class="list">${rec.map((s) => secRow(s)).join('')}</div>` : ''}
    <div class="cap">Разделы</div>
    <div class="list">${M.chapters.map((c, i) => `<a class="row hasicon chap" href="#/manual/c/${c.id}"><span class="no" style="background:${CHAP_COLORS[i]}">${c.id}</span><div class="grow"><div class="t">${esc(c.title)}</div><div class="s">${M.children(c.id).length ? `${M.children(c.id).length} ${plural(M.children(c.id).length, 'подраздел', 'подраздела', 'подразделов')}` : 'Открыть'}</div></div>${chev}</a>`).join('')}</div>`;
  };
  let t;
  inp.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { renderBody(); history.replaceState(null, '', '#/manual' + (inp.value.trim() ? '?q=' + encodeURIComponent(inp.value.trim()) : '')); curPath = location.hash.slice(1); }, 160); });
  wrap.querySelector('.x').onclick = () => { inp.value = ''; renderBody(); history.replaceState(null, '', '#/manual'); inp.focus(); };
  renderBody();
}
const secRow = (s) => `<a class="row" href="#/manual/s/${s.id}"><span class="sec-num">${s.id}</span><div class="grow"><div class="t">${esc(s.title)}</div></div>${chev}</a>`;

async function manualChapter(id) {
  const M = await manual();
  const c = M.byId[id];
  if (!M.children(id).length) return go(`#/manual/s/${id}`);
  const rows = M.sections.filter((s) => s.id.startsWith(id + '.')).map((s) => {
    const lvl = s.id.split('.').length - 1;
    const empty = !s.text;
    return `<a class="row sec-l${lvl}" href="#/manual/s/${s.id}${empty ? '' : ''}"><span class="sec-num">${s.id}</span><div class="grow"><div class="t">${esc(s.title)}${s.opt ? ' <span class="small muted">*</span>' : ''}</div></div>${chev}</a>`;
  }).join('');
  view.innerHTML = `<button class="back" data-back="#/manual">${icon('back')}<span>Руководство</span></button>${LT(c.title, `Раздел ${id}`)}<div class="list">${rows}</div>
  <div class="note">* — оборудование есть не во всех комплектациях.</div>`;
}

async function manualSection(id, q) {
  const M = await manual();
  const s = M.byId[id];
  if (!s) return go('#/manual');
  const query = q?.get?.('q') || '';
  const pr = mprefs();
  pr.recent = [id, ...(pr.recent || []).filter((x) => x !== id)].slice(0, 8); setMprefs(pr);
  const fs = pr.fs || 17;
  const kids = M.sections.filter((x) => x.id.startsWith(id + '.') && x.id.split('.').length === id.split('.').length + 1);
  const readable = M.sections.filter((x) => x.text);
  const pos = readable.findIndex((x) => x.id === id);
  const prev = pos > 0 ? readable[pos - 1] : null;
  const next = pos >= 0 && pos < readable.length - 1 ? readable[pos + 1] : null;
  const parent = id.split('.').slice(0, -1).join('.');
  const isBm = (pr.bm || []).includes(id);
  view.innerHTML = `<div class="reader" style="--fs:${fs}px">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <button class="back" data-back="${parent ? (parent.includes('.') ? `#/manual/s/${parent}` : `#/manual/c/${parent}`) : '#/manual'}">${icon('back')}<span>${parent ? esc(M.byId[parent]?.title || 'Назад') : 'Руководство'}</span></button>
      <div class="tools"><button id="fsDn" aria-label="Мельче">A−</button><button id="fsUp" aria-label="Крупнее">A+</button><button id="bm" class="${isBm ? 'on' : ''}" aria-label="Закладка">${icon('bookmark')}</button></div>
    </div>
    <div class="rh"><div class="num">РАЗДЕЛ ${esc(id)}${s.opt ? ' · не во всех комплектациях' : ''}</div><h1 data-title="${esc(s.title)}">${esc(s.title)}</h1></div>
    ${s.html ? `<div class="body" id="rBody">${s.html}</div>` : ''}
    ${kids.length ? `<div class="cap">Подразделы</div><div class="list">${kids.map((k) => secRow(k)).join('')}</div>` : ''}
    ${id === '4.1.3' ? `<button class="banner" data-go="#/indicators">${icon('warn')}<div><b>Интерактивный список индикаторов</b><span>Поиск и фильтр по цвету.</span></div></button>` : ''}
    <div class="pager"><button id="pPrev" ${prev ? '' : 'disabled'}><small>← Назад</small><span>${prev ? esc(prev.title) : ''}</span></button><button id="pNext" ${next ? '' : 'disabled'}><small>Далее →</small><span>${next ? esc(next.title) : ''}</span></button></div>
  </div>`;
  const body = $('#rBody');
  if (body) {
    body.addEventListener('click', (e) => { const im = e.target.closest('figure img, td img:not(.ico)'); if (im) zoomImage(im.src); });
    if (query) {
      const first = markInDom(body, query);
      if (first) setTimeout(() => first.scrollIntoView({ block: 'center' }), 60);
    }
  }
  const setFs = (d) => { const p2 = mprefs(); p2.fs = Math.max(14, Math.min(24, (p2.fs || 17) + d)); setMprefs(p2); $('.reader').style.setProperty('--fs', p2.fs + 'px'); };
  $('#fsDn').onclick = () => setFs(-1); $('#fsUp').onclick = () => setFs(1);
  $('#bm').onclick = (e) => { const p2 = mprefs(); const set = new Set(p2.bm || []); set.has(id) ? set.delete(id) : set.add(id); p2.bm = [...set]; setMprefs(p2); e.currentTarget.classList.toggle('on'); toast(set.has(id) ? 'Добавлено в закладки' : 'Закладка удалена'); };
  if (prev) $('#pPrev').onclick = () => go(`#/manual/s/${prev.id}`);
  if (next) $('#pNext').onclick = () => go(`#/manual/s/${next.id}`);
  bindCommon();
}
function markInDom(root, query) {
  const { stems } = searchManual.prepare(query);
  if (!stems.length) return null;
  const re = new RegExp(`(${stems.map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})[а-яёa-z0-9-]*`, 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
  let first = null;
  for (const n of nodes) {
    const t = n.nodeValue; re.lastIndex = 0;
    if (!re.test(t)) continue; re.lastIndex = 0;
    const frag = document.createDocumentFragment(); let li = 0, m;
    while ((m = re.exec(t))) { frag.append(t.slice(li, m.index)); const mk = document.createElement('mark'); mk.textContent = m[0]; frag.append(mk); first ||= mk; li = m.index + m[0].length; }
    frag.append(t.slice(li)); n.replaceWith(frag);
  }
  return first;
}

// ---------- ИНДИКАТОРЫ ----------
let IND = null;
async function indicators() {
  IND ||= await fetch('data/indicators.json').then((r) => r.json());
  const svgCache = indicators.svg ||= {};
  await Promise.all(IND.map(async (it) => { svgCache[it.n] ||= await fetch(it.icon).then((r) => r.text()); }));
  let filter = sessionStorage.getItem('gs8.indf') || 'all';
  view.innerHTML = `${LT('Индикаторы', 'Приборная панель · 38 сигналов')}
  <div class="search" id="iS">${icon('search')}<input id="iq" type="search" placeholder="Поиск: давление, ESP, ремень…" autocomplete="off"><button class="x" aria-label="Очистить">✕</button></div>
  <div class="chips" id="iF">${[['all', 'Все'], ...Object.entries(COLORS)].map(([k, v]) => `<button class="chip ${filter === k ? 'on' : ''}" data-f="${k}">${k === 'all' ? '' : `<span class="dot ${k}"></span>`}${v}</button>`).join('')}</div>
  <div id="iList"></div>
  <div class="card" style="margin-top:14px"><div class="legend">
    <div><span class="dot red"></span><span>Красный — опасность или серьёзная неисправность: безопасно остановитесь.</span></div>
    <div><span class="dot yellow"></span><span>Жёлтый — предупреждение или неисправность системы: обратитесь в сервис.</span></div>
    <div><span class="dot green"></span><span>Зелёный — функция включена и работает.</span></div>
    <div><span class="dot blue"></span><span>Синий / белый / серый — состояние системы или режим готовности.</span></div>
  </div></div>
  <div class="note">Источник — руководство, раздел 4.1.3. Звёздочка * — оборудование не во всех комплектациях. При неисправности обратитесь в сервисный центр GAC Motor.</div>`;
  const inp = $('#iq');
  const draw = () => {
    const v = inp.value.trim().toLowerCase();
    $('#iS').classList.toggle('has', !!v);
    const list = IND.filter((it) => (filter === 'all' || it.states.some((s) => s.color === filter)) && (!v || (it.name + ' ' + it.states.map((s) => s.text).join(' ')).toLowerCase().includes(v)));
    $('#iList').innerHTML = list.length ? `<div class="list">${list.map((it) => {
      const main = filter !== 'all' ? filter : it.states[0].color;
      const cols = [...new Set(it.states.map((s) => s.color))];
      return `<button class="row ind" data-n="${it.n}"><span class="lamp ${main}">${svgCache[it.n]}</span><div class="grow"><div class="t" style="font-size:16px;line-height:1.3">${esc(it.name)}${it.opt ? '<span class="muted"> *</span>' : ''}</div>
      <div class="dots">${cols.map((c) => `<span class="dot ${c}" title="${COLORS[c]}"></span>`).join('')}</div></div>${chev}</button>`;
    }).join('')}</div>` : `<div class="card empty">${icon('search')}Ничего не найдено.</div>`;
    $$('#iList [data-n]').forEach((b) => (b.onclick = () => openInd(+b.dataset.n)));
  };
  $$('#iF .chip').forEach((b) => (b.onclick = () => { filter = b.dataset.f; sessionStorage.setItem('gs8.indf', filter); $$('#iF .chip').forEach((x) => x.classList.toggle('on', x === b)); draw(); }));
  inp.addEventListener('input', draw);
  $('#iS .x').onclick = () => { inp.value = ''; draw(); };
  draw();
}
function openInd(n) {
  const it = IND.find((x) => x.n === n);
  const svg = indicators.svg[n];
  const body = `<div style="display:flex;flex-direction:column;align-items:center;text-align:center;gap:12px;margin:6px 0 16px">
    <span class="lamp lg ${it.states[0].color}">${svg}</span><div style="font-size:20px;font-weight:700;line-height:1.25">${esc(it.name)}</div>
    ${it.opt ? '<span class="tag">не во всех комплектациях</span>' : ''}</div>
    <div class="card">${it.states.map((s) => `<div class="state"><span class="lamp ${s.color}">${svg}</span><div><b style="color:var(--c-${s.color === 'white' ? 'gray' : s.color})">${esc(COLORS[s.color] || s.label)}</b><p>${esc(s.text)}</p></div></div>`).join('')}</div>
    <button class="btn sec" id="indMan">${icon('book')}Открыть в руководстве</button>`;
  const s = sheet({ title: `№ ${n}`, body });
  s.el.querySelector('#indMan').onclick = () => { s.close(); go('#/manual/s/4.1.3'); };
}

// ---------- СПРАВОЧНИК ----------
const REF_COL = { drop: '#0a84ff', tire: '#34c759', align: '#5856d6', engine: '#ff9500', ruler: '#8e8e93', battery: '#30b0c7', brake: '#ff3b30', tag: '#af52de' };
function refHome() {
  view.innerHTML = `${LT('Справочник', 'Данные руководства и сервисной книжки')}
  <div class="list">${REF.map((r) => `<a class="row hasicon" href="#/ref/${r.id}"><span class="ibox" style="background:${REF_COL[r.icon]}">${icon(r.icon)}</span><span class="grow">${esc(r.title)}</span>${chev}</a>`).join('')}</div>
  <div class="cap">Сервис и гарантия</div>
  <div class="list">
    <a class="row hasicon" href="#/ref/warranty"><span class="ibox" style="background:#34c759">${icon('shield')}</span><span class="grow">Гарантия</span>${chev}</a>
    <a class="row hasicon" href="#/ref/heavy"><span class="ibox" style="background:#ff9500">${icon('warn')}</span><span class="grow">Тяжёлые условия эксплуатации</span>${chev}</a>
    <a class="row hasicon" href="tel:${ROADSIDE.phone}"><span class="ibox" style="background:#ff3b30">${icon('phone')}</span><div class="grow"><div class="t">Помощь на дороге</div><div class="s num">${ROADSIDE.display} · круглосуточно, бесплатно</div></div>${chev}</a>
  </div>
  <div class="cap">Приложение</div>
  <div class="list">
    <button class="row hasicon" id="rSet"><span class="ibox" style="background:#8e8e93">${icon('gear')}</span><span class="grow">Настройки и резервная копия</span>${chev}</button>
    <a class="row hasicon" href="#/ref/about"><span class="ibox" style="background:#636366">${icon('info')}</span><span class="grow">О приложении</span>${chev}</a>
  </div>`;
  $('#rSet').onclick = openSettings;
}
function refDetail(id) {
  const r = REF.find((x) => x.id === id);
  if (!r) return go('#/ref');
  const tire = store.get().profile.tire;
  const rows = r.rows.map(([k, v]) => {
    const hl = id === 'tires' && ((tire === 'R19' && k === 'Шины R19') || (tire !== 'R19' && k === 'Шины R20'));
    return `<div class="row"><span class="grow" style="${hl ? 'font-weight:600' : ''}">${esc(k)}${hl ? ' <span class="tag acc">ваши</span>' : ''}</span><span class="v num ${hl ? 'strong' : ''}">${esc(v)}</span></div>`;
  }).join('');
  view.innerHTML = `<button class="back" data-back="#/ref">${icon('back')}<span>Справочник</span></button>${LT(r.title)}
  <div class="list">${rows}</div>${r.note ? `<div class="note">${esc(r.note)}</div>` : ''}
  ${id === 'fluids' ? `<button class="banner" data-go="#/manual/s/6.4">${icon('book')}<div><b>Как проверить и долить</b><span>Руководство, раздел 6.4</span></div></button>` : ''}
  ${id === 'tires' ? `<button class="banner" data-go="#/manual/s/8.4">${icon('book')}<div><b>Замена повреждённой шины</b><span>Руководство, раздел 8.4</span></div></button>` : ''}`;
  bindCommon();
}
function refPage(p) {
  if (p === 'settings') { go('#/ref'); return openSettings(); }
  if (p === 'heavy') {
    view.innerHTML = `<button class="back" data-back="#/ref">${icon('back')}<span>Справочник</span></button>${LT('Тяжёлые условия')}
    <div class="card">${esc(HEAVY.text)}</div><div class="cap">Дополнительно к ТО</div>
    <div class="list">${HEAVY.rules.map((r) => `<div class="row"><span class="grow">${esc(r)}</span></div>`).join('')}</div>
    <div class="list" style="margin-top:16px"><div class="row"><span class="grow">Учитывать в расчётах</span><span class="switch"><input type="checkbox" id="hv" ${store.get().profile.heavy ? 'checked' : ''}><span></span></span></div></div>
    <div class="note">Источник — сервисная книжка, «Дополнительные меры при эксплуатации автомобиля в тяжёлых условиях».</div>`;
    $('#hv').onchange = (e) => { store.setProfile({ heavy: e.target.checked }); toast(e.target.checked ? 'Интервалы сокращены' : 'Обычные интервалы'); };
    return;
  }
  if (p === 'about') {
    view.innerHTML = `<button class="back" data-back="#/ref">${icon('back')}<span>Справочник</span></button>${LT('О приложении')}
    <div class="card"><b>GS8</b> — личный помощник владельца GAC GS8: сервисный журнал, график ТО, ресурс расходников, руководство по эксплуатации и индикаторы. Работает без интернета.</div>
    <div class="list" style="margin-top:12px">
      <div class="row"><span class="grow">Версия</span><span class="v">${window.GS8_VERSION || '—'}</span></div>
      <div class="row"><span class="grow">Руководство</span><span class="v">141 раздел</span></div>
      <div class="row"><span class="grow">Регламент ТО</span><span class="v">ТО-0 … ТО-10</span></div>
      <div class="row"><span class="grow">Срок службы</span><span class="v">${SERVICE_LIFE.years} лет / ${fmtKm(SERVICE_LIFE.km)} км</span></div>
    </div>
    <div class="note">Данные взяты из руководства по эксплуатации и сервисной книжки GAC GS8. При расхождении приоритет у документов дилера и фактической комплектации автомобиля. Все записи хранятся только на устройстве.</div>`;
    return;
  }
  // гарантия
  const ws = warrantyStatus();
  const pd = store.get().profile.purchaseDate;
  view.innerHTML = `<button class="back" data-back="#/ref">${icon('back')}<span>Справочник</span></button>${LT('Гарантия', pd ? `с ${fmtDate(pd)}` : 'укажите дату покупки в настройках')}
  <div class="list">${ws.map((w) => {
    const lim = [w.years ? `${w.years} ${plural(w.years, 'год', 'года', 'лет')}` : w.months ? `${w.months} мес.` : '', w.km ? `${fmtKm(w.km)} км` : ''].filter(Boolean).join(' / ');
    const fromPurchase = w.fromPurchase !== false;
    const status = !pd || !fromPurchase ? '' : `<span class="tag ${w.active ? (w.used > .85 ? 'warn' : 'ok') : 'bad'}">${w.active ? (w.end ? 'до ' + fmtDate(w.end, { day: 'numeric', month: 'short', year: 'numeric' }) : 'действует') : 'истекла'}</span>`;
    return `<div class="row part"><div class="top"><span class="nm" style="font-size:15px;line-height:1.3">${esc(w.name)}</span>${status}</div>
      <div class="small muted" style="margin-top:3px">${lim}${fromPurchase ? '' : ' с даты покупки детали'}</div>
      ${pd && fromPurchase ? `<div class="meter"><i class="${w.active ? (w.used > .85 ? 'warn' : '') : 'bad'}" style="width:${Math.round(w.used * 100)}%"></i></div>` : ''}</div>`;
  }).join('')}</div>
  <div class="note">Срок — «что наступит раньше». Условие гарантии — своевременное плановое ТО у официального дилера и хранение заказ-нарядов. Перепробег между ТО более 500 км ограничивает гарантию. Фильтры, жидкости, колодки, щётки, лампы и другие изнашиваемые детали гарантией не покрываются.</div>
  <a class="banner" href="tel:${ROADSIDE.phone}" style="color:inherit">${icon('phone')}<div><b>GAC Assistance ${ROADSIDE.display}</b><span>Эвакуация до дилера (до 200 км), техпомощь, подвоз топлива, замена колеса, запуск от внешнего источника, аварийный комиссар — бесплатно и круглосуточно.</span></div></a>`;
}

// ---------- запуск ----------
store.sub(() => {});
window.addEventListener('pageshow', () => { if (!location.hash) location.replace('#/home'); });
render();

// Service Worker и обновления
if ('serviceWorker' in navigator) {
  let reloaded = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (!reloaded) { reloaded = true; location.reload(); } });
  navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).then((reg) => {
    const kick = (w) => w && w.postMessage('skip');
    kick(reg.waiting);
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing;
      nw && nw.addEventListener('statechange', () => { if (nw.state === 'installed') kick(nw); });
    });
    reg.update().catch(() => {});
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') reg.update().catch(() => {}); });
  }).catch(() => {});
}
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
