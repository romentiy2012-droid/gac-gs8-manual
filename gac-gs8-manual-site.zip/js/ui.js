// Общие UI-хелперы: разметка, иконки, шторки, тосты, зум картинок
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const P = {
  chev: '<svg class="chev" viewBox="0 0 8 14"><path d="M1 1l6 6-6 6"/></svg>',
  back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  gear: '<path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z"/><path d="M19.4 13.5a7.7 7.7 0 0 0 0-3l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.5A7.6 7.6 0 0 0 7 6.5l-2.4-1-2 3.4 2 1.6a7.7 7.7 0 0 0 0 3l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 2.6 1.5l.4 2.5h4l.4-2.5a7.6 7.6 0 0 0 2.6-1.5l2.4 1 2-3.4z"/>',
  phone: '<path d="M5 3h3.5l2 5-2.5 1.5a11 11 0 0 0 6.5 6.5L16 13.5l5 2V19a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
  drop: '<path d="M12 3s6 6.4 6 11a6 6 0 0 1-12 0c0-4.6 6-11 6-11z"/>',
  tire: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v5.5M12 15.5V21M3 12h5.5M15.5 12H21"/>',
  warn: '<path d="M12 3 2 20h20zM12 9.5v4.5M12 17v.2"/>',
  align: '<path d="M7 4l-2 16M17 4l2 16M4 12h16"/>',
  engine: '<path d="M4 10h2V8h3V6h5v2h3l2 3h2v5h-2l-2 3H9l-2-2H4z"/>',
  ruler: '<path d="M3 17 17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2"/>',
  battery: '<rect x="3" y="7" width="18" height="12" rx="2"/><path d="M7 7V5h3v2M14 7V5h3v2M7 13h4M15 11v4M13 13h4"/>',
  brake: '<circle cx="12" cy="12" r="6"/><path d="M4.5 7A9 9 0 0 0 4.5 17M19.5 7a9 9 0 0 1 0 10"/><path d="M12 9v3.5M12 14.8v.2"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.4"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.1L3.6 17.1a1.9 1.9 0 0 0 2.7 2.7l5.7-5.7a4 4 0 0 0 5.1-5.4l-2.5 2.5-2.3-.6-.6-2.3z"/>',
  book: '<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H11v17H5.5A1.5 1.5 0 0 0 4 21.5zM20 4.5A1.5 1.5 0 0 0 18.5 3H13v17h5.5a1.5 1.5 0 0 1 1.5 1.5z"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 9a4.5 4.5 0 0 1-.5 9z"/><path d="M12 11v6M9.5 14.5 12 17l2.5-2.5"/>',
  car: '<path d="M4 16v-4l2-5h12l2 5v4M4 16h16M4 16v2h3v-2M17 16v2h3v-2"/><circle cx="7.5" cy="13" r=".6"/><circle cx="16.5" cy="13" r=".6"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  share: '<path d="M12 3v12M8 7l4-4 4 4M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>',
  gauge: '<path d="M12 3a9 9 0 1 0 9 9M12 12l5-5M12 3v3M3 12h3M18 12h3"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.2"/>',
};
export const icon = (n, cls = '') => (n === 'chev' || n === 'back' ? P[n] : `<svg class="${cls}" viewBox="0 0 24 24">${P[n] || ''}</svg>`);
export const chev = P.chev;

// ---------- тост ----------
let tt;
export function toast(msg, action) {
  const el = $('#toast');
  el.innerHTML = `<span>${esc(msg)}</span>${action ? `<button>${esc(action.label)}</button>` : ''}`;
  if (action) el.querySelector('button').onclick = () => { el.classList.remove('show'); action.fn(); };
  el.classList.add('show');
  clearTimeout(tt); tt = setTimeout(() => el.classList.remove('show'), action ? 5000 : 2400);
}

// ---------- шторка (bottom sheet) ----------
const stack = [];
export function sheet({ title = '', left = 'Закрыть', right = null, onRight = null, body = '', full = false, onClose = null }) {
  const root = $('#sheetRoot');
  const wrap = document.createElement('div');
  wrap.className = 'sheet-wrap';
  wrap.innerHTML = `<div class="sheet-bd"></div><div class="sheet${full ? ' full' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="grab"><i></i></div>
    <div class="sh"><button class="l">${esc(left)}</button><h2>${esc(title)}</h2><button class="r">${right ? esc(right) : ''}</button></div>
    <div class="sb"></div></div>`;
  root.appendChild(wrap);
  const sb = wrap.querySelector('.sb');
  if (typeof body === 'string') sb.innerHTML = body; else sb.appendChild(body);
  const sh = wrap.querySelector('.sheet');
  let closed = false;
  const api = {
    el: sb, sheet: sh,
    close() {
      if (closed) return; closed = true;
      sh.classList.add('out'); wrap.querySelector('.sheet-bd').classList.add('out');
      setTimeout(() => wrap.remove(), 250);
      stack.splice(stack.indexOf(api), 1);
      document.body.style.overflow = stack.length ? 'hidden' : '';
      onClose && onClose();
    },
    setRight(label, enabled = true) { const b = wrap.querySelector('.sh .r'); b.textContent = label; b.disabled = !enabled; b.style.opacity = enabled ? 1 : .4; },
  };
  wrap.querySelector('.sheet-bd').onclick = api.close;
  wrap.querySelector('.sh .l').onclick = api.close;
  const rb = wrap.querySelector('.sh .r');
  if (right && onRight) rb.onclick = () => onRight(api); else rb.style.visibility = 'hidden';
  // свайп вниз для закрытия
  let y0 = null, dy = 0;
  const start = (e) => { y0 = e.touches[0].clientY; dy = 0; sh.style.transition = 'none'; };
  const move = (e) => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); sh.style.transform = `translateY(${dy}px)`; };
  const end = () => { if (y0 == null) return; sh.style.transition = 'transform .25s'; if (dy > 110) api.close(); else sh.style.transform = ''; y0 = null; };
  for (const h of wrap.querySelectorAll('.grab, .sh')) { h.addEventListener('touchstart', start, { passive: true }); h.addEventListener('touchmove', move, { passive: true }); h.addEventListener('touchend', end); }
  // свайп вниз по контенту, если он прокручен в начало
  sb.addEventListener('touchstart', (e) => { if (sb.scrollTop <= 0) start(e); }, { passive: true });
  sb.addEventListener('touchmove', (e) => { if (y0 != null && sb.scrollTop <= 0 && e.touches[0].clientY > y0) move(e); else if (y0 != null) { y0 = null; sh.style.transform = ''; } }, { passive: true });
  sb.addEventListener('touchend', end);
  stack.push(api);
  document.body.style.overflow = 'hidden';
  return api;
}
export function closeAllSheets() { [...stack].forEach((s) => s.close()); }
export const hasSheet = () => stack.length > 0;

// ---------- зум изображения ----------
export function zoomImage(src) {
  const z = document.createElement('div');
  z.className = 'zoom';
  z.innerHTML = `<button class="iconbtn close" aria-label="Закрыть">${icon('close')}</button><img src="${esc(src)}" alt="">`;
  document.body.appendChild(z);
  const img = z.querySelector('img');
  let last = 0;
  img.addEventListener('click', (e) => {
    const now = Date.now();
    if (now - last < 320 || true) { z.classList.toggle('z2'); }
    last = now; e.stopPropagation();
  });
  z.querySelector('.close').onclick = () => z.remove();
  z.addEventListener('click', (e) => { if (e.target === z) z.remove(); });
}

export function confirmSheet(text, okLabel, fn) {
  const s = sheet({ title: '', left: 'Отмена', body: `<p style="text-align:center;margin:6px 8px 4px;font-size:15px" class="muted">${esc(text)}</p><button class="btn" style="background:var(--bad)">${esc(okLabel)}</button>` });
  s.el.querySelector('.btn').onclick = () => { s.close(); fn(); };
}

// ---------- кольцо прогресса ----------
export function ring(p, color, center) {
  const R = 40, C = 2 * Math.PI * R;
  return `<div class="ring"><svg viewBox="0 0 92 92"><circle class="trk" cx="46" cy="46" r="${R}" fill="none" stroke-width="8"/>
  <circle class="bar" cx="46" cy="46" r="${R}" fill="none" stroke="${color}" stroke-width="8" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - Math.max(0.02, Math.min(1, p)))}"/></svg><div class="c">${center}</div></div>`;
}
